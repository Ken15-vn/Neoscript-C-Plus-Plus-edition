@echo off
title NeoScript C++ Edition
"Neoscript C++ edition.exe" ide.ns
pause