@echo off
title NeoScript C++ Edition
"x64\Debug\Neoscript C++ edition.exe" ide.ns
pause