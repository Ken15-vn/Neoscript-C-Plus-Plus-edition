#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <thread>
#include <chrono>
#include <algorithm>

using namespace std;

// Kho lưu trữ biến: Lưu tất cả dưới dạng chuỗi để linh hoạt
map<string, string> variables;

// Hàm kiểm tra xem một chuỗi có phải là số không
bool is_number(const string& s) {
    if (s.empty()) return false;
    char* p;
    strtod(s.c_str(), &p);
    return *p == 0;
}

// Hàm cắt khoảng trắng
string trim(const string& s) {
    size_t first = s.find_first_not_of(" \t\r\n");
    if (string::npos == first) return s;
    size_t last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, (last - first + 1));
}

void run_ns(string file_path) {
    ifstream file(file_path);
    if (!file.is_open()) {
        cout << "System Error: Could not open " << file_path << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        line = trim(line);
        if (line.empty() || line.find("note") == 0) continue;

        size_t space_pos = line.find(' ');
        string cmd = line.substr(0, space_pos);
        string arg = (space_pos != string::npos) ? line.substr(space_pos + 1) : "";

        // --- LỆNH SET ---
        if (cmd == "set") {
            size_t s_pos = arg.find(' ');
            string name = arg.substr(0, s_pos);
            string val = arg.substr(s_pos + 1);
            if (!val.empty() && val[0] == '"') val = val.substr(1, val.size() - 2);
            variables[name] = val;
        }
        // --- LỆNH WRITE ---
        else if (cmd == "write") {
            if (!arg.empty() && arg[0] == '"') arg = arg.substr(1, arg.size() - 2);
            if (variables.count(arg)) cout << variables[arg] << endl;
            else cout << arg << endl;
        }
        // --- LỆNH ADD (Toán học nâng cao) ---
        else if (cmd == "add") {
            size_t s_pos = arg.find(' ');
            string name = arg.substr(0, s_pos);
            string val_to_add = arg.substr(s_pos + 1);
            double current = stod(variables[name]);
            double adder = variables.count(val_to_add) ? stod(variables[val_to_add]) : stod(val_to_add);
            variables[name] = to_string(current + adder);
        }
        // --- LỆNH SUB ---
        else if (cmd == "sub") {
            size_t s_pos = arg.find(' ');
            string name = arg.substr(0, s_pos);
            string val_to_sub = arg.substr(s_pos + 1);
            double current = stod(variables[name]);
            double subber = variables.count(val_to_sub) ? stod(variables[val_to_sub]) : stod(val_to_sub);
            variables[name] = to_string(current - subber);
        }
        // --- LỆNH INPUT (Số) ---
        else if (cmd == "input") {
            string in;
            cin >> in;
            variables[arg] = in;
        }
        // --- LỆNH INPUT_STR (Chuỗi) ---
        else if (cmd == "input_str") {
            string in;
            getline(cin >> ws, in);
            variables[arg] = in;
        }
        // --- LỆNH WAIT ---
        else if (cmd == "wait") {
            this_thread::sleep_for(chrono::milliseconds((int)(stod(arg) * 1000)));
        }
        // --- LỆNH CLEAR ---
        else if (cmd == "clear") {
            system("cls");
        }
        // --- LỆNH COLOR ---
        else if (cmd == "color") {
            if (arg == "\"red\"") system("color 04");
            else if (arg == "\"green\"") system("color 02");
            else if (arg == "\"cyan\"") system("color 03");
            else system("color 07");
        }
    }
    file.close();
}

int main(int argc, char* argv[]) {
    string target = (argc > 1) ? argv[1] : "ide.ns";
    run_ns(target);
    return 0;
}